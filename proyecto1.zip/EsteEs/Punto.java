
/**
 * Write a description of class punto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Punto
{
    // instance variables - replace the example below with your own
    private Rectangle punto;
    private int xPosition;
    private int yPosition;
    /**
     * Constructor for objects of class punto
     */
    public Punto(int x, int y)
    {
        // initialise instance variables
        xPosition = x;
        yPosition = y;
        punto = new Rectangle();
        punto.changeSize(1,1);
        punto.changePosition(xPosition,yPosition);

        
    }
    
    public void makeInvisible(){
        punto.makeInvisible();
    }
    
    public void makeVisible(){
        punto.makeVisible();
    }
    
    public int getX(){
        return xPosition;        
    }
    
    public int getY(){
        return yPosition;
    }
}
