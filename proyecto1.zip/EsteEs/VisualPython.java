import java.util.*;
/**
 * Write a description of class VisualPython here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VisualPython
{
    // instance variables - replace the example below with your own
    private int width;
    private int height;
    private Rectangle tablero;
    private ArrayList<Punto> puntos = new ArrayList<Punto>();
    private ArrayList<Rectangle> figuras = new ArrayList<Rectangle>();
    private ArrayList<Rectangle> figurasFold = new ArrayList<Rectangle>();
    private boolean isVisible = false;
    //private ArrayList<boolean> uOperacion = new ArrayList<boolean>();
    

    /**
    * Constructor for objects of class VisualPython
    */
    public VisualPython(int width, int height)
    {   
        // initialise instance variables
        this.width = width;
        this.height = height;
        
        Canvas canvas = Canvas.getCanvas(width,height);
        tablero = new Rectangle();
        tablero.changeSize(height,width);
        tablero.changePosition(0, 0);
        tablero.changeColor("white");
        //tablero.makeVisible();
                       
    }
    
    public void putCornerTopLeft(int[] corner){
        Punto puntoT = new Punto(corner[0],corner[1]);
        puntos.add(puntoT);
        if (isVisible){puntoT.makeVisible();}
    }
    
    public void putCornerBottomRight(int[] corner){
        Punto puntoB = new Punto(corner[0],corner[1]);
        puntos.add(puntoB);
        if (isVisible){puntoB.makeVisible();}
    }
    
    public void removeCorner(int[] corner){
        
        for(int i=0;i<puntos.size();i++){
            if(puntos.get(i).getX() == corner[0] && puntos.get(i).getY() == corner[1]){
                puntos.get(i).makeInvisible();
                puntos.remove(i);
                break;
                
                
            }
            
        }                     
    }
    
    public void putBlock(String color,int[] topLeft,int[] bottomRight){
        boolean banderaL = false;
        boolean banderaR = false;
        Punto puntoT = null;
        Punto puntoB = null;
        
        
        for(int i=0;i<puntos.size();i++){
            if (puntos.get(i).getX() == topLeft[0] && puntos.get(i).getY()==topLeft[1]){
                banderaL = true;
                puntoT = puntos.get(i);
            }
            if (puntos.get(i).getX() == bottomRight[0] && puntos.get(i).getY()==bottomRight[1]){
                banderaR = true;
                puntoB = puntos.get(i);
                
            }
        }

          
        if (banderaL && banderaR){
            Rectangle block = new Rectangle();
            puntoT.makeInvisible(); 
            puntoB.makeInvisible();            
            block.changeColor(color);
            block.changeSize(Math.abs(topLeft[1]-bottomRight[1]),Math.abs(topLeft[0]-bottomRight[0]));
            block.changePosition(topLeft[0],topLeft[1]);
            figuras.add(block);
            if (isVisible){block.makeVisible();}
            
        }
    }
    
    public void dissolveBlock(String color){
        int indice = -1;
        
        for(int i=0;i<figuras.size();i++){            
            if (figuras.get(i).getColor().equals(color)){
                figuras.get(i).makeInvisible();
                for(int j=0;j<puntos.size();j++){
                    if (puntos.get(j).getX()==figuras.get(i).getX() && puntos.get(j).getY()==figuras.get(i).getY()){
                        puntos.get(j).makeVisible();
                        indice = i;
                    }
                    if (puntos.get(j).getX()==figuras.get(i).getX1() && puntos.get(j).getY()==figuras.get(i).getY1()){
                        puntos.get(j).makeVisible();
                        indice = i;
                    }                    
                }
            }
        }
        
        figuras.remove(indice);
        
    }
    
    public void removeBlock(String color){
        int[] topLeft = new int[2];
        int[] bottomRight = new int[2];
        
        boolean bandeL = false;
        boolean bandeR = false;
        
        for(int i=0;i<figuras.size();i++){            
            if (figuras.get(i).getColor().equals(color)){                
                for(int j=0;j<puntos.size();j++){
                    if (puntos.get(j).getX()==figuras.get(i).getX() && puntos.get(j).getY()==figuras.get(i).getY()){
                        topLeft[0]=puntos.get(j).getX();
                        topLeft[1]=puntos.get(j).getY();
                        bandeL = true;
                        figuras.get(i).makeInvisible();
                    }
                    if (puntos.get(j).getX()==figuras.get(i).getX1() && puntos.get(j).getY()==figuras.get(i).getY1()){
                        bottomRight[0]=puntos.get(j).getX();
                        bottomRight[1]=puntos.get(j).getY();
                        bandeR = true;
                        figuras.get(i).makeInvisible();                        
                    }
                    if (bandeL && bandeR){
                        break;
                    }
                }                
            }
            if (bandeL && bandeR){
                figuras.remove(i);
                removeCorner(topLeft);
                removeCorner(bottomRight);
                break;
            }
        }

        
    }
    
    public void foldBlock(String color){
        int[] newPunto = new int[2];
        for(int i=0;i<figuras.size();i++){
            if (figuras.get(i).getColor().equals(color)){
                figurasFold.add(figuras.get(i));
                figuras.get(i).makeInvisible();
                Rectangle block = new Rectangle();
                block.changeColor(color);
                block.changeSize(1,figuras.get(i).getWidth());
                block.changePosition(figuras.get(i).getX(),figuras.get(i).getY());
                figuras.remove(i);
                figuras.add(block);
                newPunto[0]=block.getX1();
                newPunto[1]=block.getY1();
                putCornerBottomRight(newPunto);
                if (isVisible){block.makeVisible();}
                break;
            }
        }
                
    }
    
    public void unFoldBlock(String color){
        boolean change = false;
        
        for(int i=0;i<figuras.size();i++){
            if (figuras.get(i).getColor().equals(color)){
                for(int j=0;j<figurasFold.size();j++){
                    if (figurasFold.get(j).getColor().equals(color)){
                        figuras.get(i).makeInvisible();
                        figuras.remove(i);
                        figuras.add(figurasFold.get(j));
                        if (isVisible){figurasFold.get(j).makeVisible();}
                        figurasFold.remove(j);
                        change = true;
                        break;
                    }
                }
            }
            if (change){
                break;
            }
        }
        
    }
    
    public void makeVisible(){
        for(int i=0;i<figuras.size();i++){
            figuras.get(i).makeVisible();
        }
        
        for(int i=0;i<puntos.size();i++){
            puntos.get(i).makeVisible();
        }
        
        isVisible = true;
    }
    
    public void makeInvisible(){
                for(int i=0;i<figuras.size();i++){
            figuras.get(i).makeInvisible();
        }
        
        for(int i=0;i<puntos.size();i++){
            puntos.get(i).makeInvisible();
        }
        
        isVisible = false;
    }
    

}



    